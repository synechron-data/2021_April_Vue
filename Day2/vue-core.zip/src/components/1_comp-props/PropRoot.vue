<template>
	<div>
		<ComponentWithProps
			:id="1"
			:name="'Manish'"
			:address="{ city: 'Pune', state: 'MH' }"
			:items="['Manish', 'Abhijeet']"
			:display="() => {}"
		/>
	</div>
</template>

<script>
	import ComponentWithProps from "./ComponentWithProps.vue";
	export default {
		name: "PropRoot",
		components: { ComponentWithProps },
	};
</script>