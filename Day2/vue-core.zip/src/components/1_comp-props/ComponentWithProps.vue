<template>
	<div>
		<h1 class="text-info">Component With Props</h1>
		<h2>Id: {{ id }}</h2>
		<h2>Name: {{ name }}</h2>
		<h2>Address: {{ address }}</h2>
		<h2>Items: {{ items }}</h2>
		<hr />
		<h2>num: {{ num }}</h2>
		<h2>Computed num: {{ numDouble }}</h2>
        <h2>Computed city: {{ city }}</h2>
        <h2>Computed state: {{ state }}</h2>
	</div>
</template>

<script>
	export default {
		name: "ComponentWithProps",
		// props: ['id', 'name', 'address'],
		data: function () {
			return {
				num: 20,
			};
		},
		props: {
			id: {
				type: Number,
				required: true,
			},
			name: {
				type: String,
				required: true,
			},
			address: {
				type: Object,
				required: true,
			},
			items: {
				type: Array,
				required: true,
				validator: (prop) => prop.every((i) => typeof i === "string"),
			},
			display: {
				type: Function,
				default: function () {
					alert("From Component");
				},
			},
		},
		computed: {
			numDouble: function () {
				return this.num * 2;
			},
			city() {
				return `Your City is ${this.address.city}`;
			},
            state() {
				return `Your State is ${this.address.state}`;
			},
		},
	};
</script>