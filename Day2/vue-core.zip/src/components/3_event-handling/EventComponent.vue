<template>
	<div>
		<h1 class="text-info">Handling Events</h1>
		<button class="btn btn-primary" v-on:click="hello">Click</button>
		<button class="btn btn-primary" @click="hello">Click</button>
		<button class="btn btn-primary" @click="test()">Click</button>
		<button class="btn btn-primary" @click="test('Hello from Template')">
			Click
		</button>
		<a
			href="https://www.google.com"
			@click="a_click('Hello from Template', $event)"
			>Google</a
		>
		<hr />
		<h2>Modifiers</h2>
		<a
			href="https://www.google.com"
			v-on:click.prevent="test('Hello from Template')"
			>Google</a
		>
		<br />
		<a
			href="https://www.google.com"
			@click.prevent="test('Hello from Template')"
			>Google</a
		>
		<br />
		<a
			href="https://www.google.com"
			@click.prevent.once="test('Hello from Template')"
			>Google</a
		>
		<br />
		<input type="text" @keyup.enter="onEnter" />
		<h2 @click.ctrl="onCClick" class="text-success">
			Do Something when user do, ctrl + click
		</h2>
	</div>
</template>

<script>
	export default {
		name: "EventComponent",
		methods: {
			hello() {
				alert("Hello Handled...");
			},
			test(msg) {
				console.log("Test Executed....");
				console.log("Message is", msg);
			},
			a_click(msg, e) {
				e.preventDefault();
				console.log("Message is", msg);
			},
			onEnter() {
				alert("Enter Key Pressed");
			},
			onCClick() {
				alert("Ctrl + Click, done on the h2 tag");
			},
		},
	};
</script>