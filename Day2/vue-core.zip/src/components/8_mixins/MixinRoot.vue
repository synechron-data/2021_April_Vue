<template>
	<div>
		<ComponentOne />
		<ComponentTwo />
	</div>
</template>

<script>
	import ComponentOne from "./ComponentOne.vue";
	import ComponentTwo from "./ComponentTwo.vue";
	export default {
		name: "MixinRoot",
		components: { ComponentOne, ComponentTwo },
	};
</script>