<template>
	<div>
		<br />
		<h2 class="text-success text-center">Sibling Communication</h2>
		<br />
		<h3 class="alert alert-danger" v-if="message">{{ message }}</h3>
		<br />
		<Counter
			:interval="10"
			ref="c1"
			@flag-changed="handleFlagChanged"
			@count-changed="handleCountChanged"
		/>
		<br />
		<br />
		<CounterSibling :current_count_via_prop="ccount"/>
		<br />
		<br />
		<div class="text-center">
			<button class="btn btn-warning btn-block" @click="p_reset">
				Parent Reset
			</button>
		</div>
	</div>
	<!-- <div>
		<br />
		<h2 class="text-success text-center">
			Child to Parent Communication via Events
		</h2>
		<br />
		<h3 class="alert alert-danger" v-if="message">{{ message }}</h3>
		<br />
		<Counter :interval="10" ref="c1" v-on:flag-changed="handleFlagChanged" />
		<br />
		<Counter :interval="10" ref="c2" @flag-changed="handleFlagChanged" />
		<br />
		<br />
		<div class="text-center">
			<button class="btn btn-warning btn-block" @click="p_reset">
				Parent Reset
			</button>
		</div>
	</div> -->
	<!-- <div>
		<br />
		<h2 class="text-success text-center">
			Passing Parent Method Reference to Child - Anti Pattern
		</h2>
		<br />
		<h3 class="alert alert-danger" v-if="message">{{ message }}</h3>
		<br />
		<Counter :interval="10" ref="c1" :onMax="updateMessage" />
		<br />
		<br />
		<div class="text-center">
			<button class="btn btn-warning btn-block" @click="p_reset">
				Parent Reset
			</button>
		</div>
	</div> -->

	<!-- <div>
		<br />
		<h2 class="text-success text-center">Calling Child Method from Parent</h2>
		<Counter :interval="10" ref="c1" />
		<br />
		<br />
		<div class="text-center">
			<button class="btn btn-warning btn-block" @click="p_reset">
				Parent Reset
			</button>
		</div>
	</div> -->

	<!-- <div>
		<Counter />
		<br />
		<Counter :interval="10" />
	</div> -->
</template>

<script>
	import Counter from "./Counter.vue";
	import CounterSibling from "./CounterSibling.vue";
	export default {
		name: "CalculatorAssignment",
		components: { Counter, CounterSibling },
		data() {
			return {
				message: "",
				ccount: 0
			};
		},
		methods: {
			p_reset() {
				// console.log(this.$refs);
				this.$refs.c1.reset();
			},
			updateMessage(flag) {
				if (flag)
					this.message = "Max Click Reached, click reset button to restart";
				else this.message = "";
			},
			handleFlagChanged(flag) {
				if (flag)
					this.message = "Max Click Reached, click reset button to restart";
				else this.message = "";
			},
			handleCountChanged(newCount) {
				this.ccount = newCount;
			},
		},
	};
</script>