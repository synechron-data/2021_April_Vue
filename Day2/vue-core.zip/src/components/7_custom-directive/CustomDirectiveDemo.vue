<template>
	<div>
		<h3 v-cc></h3>
		<h4 v-cc></h4>
		<p v-cc></p>
		<hr />
		<h3 v-ccv="'2px solid red'"></h3>
        <hr />
		<h3 v-ccd:border="'2px solid red'" v-ccd:color="'blue'"></h3>
        <hr/>
        <div v-demo:data.test.a="'Hello from Root'" v-highlight="'yellow'"></div>
	</div>
</template>

<script>
	export default {
		name: "CustomDirectiveDemo",
	};
</script>