<template>
	<div class="container">
		<!-- <prop-root /> -->
		<!-- <method-root /> -->
		<!-- <event-component /> -->
		<!-- <data-binding /> -->
		<!-- <calculator-assignment /> -->
		<!-- <counter-assignment /> -->
		<!-- <slot-root /> -->
		<!-- <dynamic-root /> -->
		<!-- <custom-directive-demo /> -->
		<!-- <mixin-root /> -->
		<filter-demo />
	</div>
</template>

<script>
	// import PropRoot from "../1_comp-props/PropRoot.vue";
	// import MethodRoot from "../2_comp-methods/MethodRoot.vue";
	// import EventComponent from "../3_event-handling/EventComponent.vue";
	// import DataBinding from "../4_two-way-binding/DataBinding.vue";
	// import CalculatorAssignment from "../assignment/CalculatorAssignment.vue";
	// import CounterAssignment from "../assignment/CounterAssignment.vue";
	// import SlotRoot from "../5_slots/SlotRoot.vue";
	// import DynamicRoot from "../6_dynamic-components/DynamicRoot.vue";
	// import CustomDirectiveDemo from "../7_custom-directive/CustomDirectiveDemo.vue";
	// import MixinRoot from "../8_mixins/MixinRoot.vue";
	import FilterDemo from '../9_filters/FilterDemo.vue';

	export default {
		name: "RootComponent",
		components: {
			// PropRoot,
			// MethodRoot,
			// EventComponent,
			// DataBinding,
			// CalculatorAssignment,
			// CounterAssignment,
			// SlotRoot,
			// DynamicRoot,
			// CustomDirectiveDemo,
			// MixinRoot,
			FilterDemo,
		},
	};
</script>