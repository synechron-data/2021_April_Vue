<template>
	<div>
		<br />
		<br />
		<List :items="listItems">
			<div slot-scope="row" class="list-group-item" v-highlight="'yellow'">
				<span class="badge badge-primary">
					{{ row.item.id }}
				</span>
				{{ row.item.name }}
				<i class="bi bi-person"></i>
			</div>
		</List>
		<br />
		<MyFrame>
			<img src="../../assets/logo.png" />
		</MyFrame>
		<br />
		<br />
		<MyFrame> </MyFrame>
		<br />
		<br />
		<Button />
		<Button> Click to Change </Button>
		<Button>
			<i class="bi bi-alarm"></i>
		</Button>
		<Button> <i class="bi bi-person"></i> Profile </Button>
		<br />
		<br />
		<TitledFrame>
			<template v-slot:title> My Image Title </template>
			<img src="../../assets/logo.png" />
		</TitledFrame>
	</div>
</template>

<script>
	import Button from "./Button.vue";
	import List from "./List.vue";
	import MyFrame from "./MyFrame.vue";
	import TitledFrame from "./TitledFrame.vue";
	export default {
		name: "SlotRoot",
		components: { MyFrame, Button, TitledFrame, List },
		data() {
			return {
				listItems: [
					{ id: 1, name: "Manish" },
					{ id: 2, name: "Abhijeet" },
					{ id: 3, name: "Ramakant" },
					{ id: 4, name: "Subodh" },
				],
			};
		},
	};
</script>