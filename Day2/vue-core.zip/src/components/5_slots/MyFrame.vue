<template>
    <div class="frame">
        <h1>This the Frame Component</h1>
        <slot>This is the default Content if nothing is sent</slot>
    </div>
</template>

<script>
    export default {
        name: "MyFrame"
    }
</script>

<style scoped>
    .frame{
        border: 2px solid blue;
    }
</style>