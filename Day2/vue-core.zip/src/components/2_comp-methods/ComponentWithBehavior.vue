<template>
	<div>
		<h1 class="text-info">Component With Behavior</h1>
		<h2 class="text-info">Id: {{ id }}</h2>
		<h2 class="text-info">Count: {{ count }}</h2>
		<button class="btn btn-primary" v-on:click="changeCount">Click</button>
		<button class="btn btn-primary" @click="changeCount">Click</button>
		<hr />
		<h2>Props Area</h2>
		<h2 class="text-info">Name: {{ name }}</h2>
		<h2 class="text-info">Address: {{ address }}</h2>
		<h2>Data(State) Area</h2>
		<h2 class="text-info">Name: {{ sname }}</h2>
		<h2 class="text-info">Address: {{ saddress }}</h2>
		<button class="btn btn-primary" @click="handleChange">Click</button>
	</div>
</template>

<script>
	export default {
		name: "ComponentWithBehavior",
		data() {
			return {
				id: 1,
				count: 0,
				sname: this.name,
				saddress: { ...this.address },
			};
		},
		props: {
			name: {
				type: String,
				default: "No Name",
			},
			address: {
				type: Object,
				required: true,
			},
		},
		methods: {
			changeCount() {
				this.count += 1;
			},
			handleChange() {
				// Props should be treated as readOnly
				// this.name = "Abhijeet";
				// this.address.city = "Mumbai";

				// Change State
				this.sname = "Abhijeet";
				this.saddress.city = "Mumbai";
			},
		},
	};
</script>