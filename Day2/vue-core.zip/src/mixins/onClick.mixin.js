export default {
    methods: {
        onClick(value) {
            alert(`From MixIn - ${value}`);
        },
        handleClick(value) {
            alert(`From MixIn - ${value}`);
        }
    },
}