const changeContentAndStyleWithArgs = {
    bind(el, binding) {
        el.innerHTML = "Content & Border Added By the Directive - Taking Arguments";
        el.style[binding.arg] = binding.value;
    }
};

export default changeContentAndStyleWithArgs;