const changeContentAndStyle = {
    bind(el, binding) {
        el.innerHTML = "Content & Border Added By the Directive";
        el.style.border = binding.value;
    }
};

export default changeContentAndStyle;