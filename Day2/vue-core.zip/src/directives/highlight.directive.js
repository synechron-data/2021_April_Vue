const highlightDirective = {
    bind(el, binding) {
        el.addEventListener('mouseenter', () => {
            el.style.background = binding.value || 'skyblue';
        });
        el.addEventListener('mouseleave', () => {
            el.style.background = "";
        });
    }
};

export default highlightDirective;