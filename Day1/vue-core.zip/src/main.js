// import Vue from 'vue'

// Vue.config.productionTip = false

// // Local Component
// const GreetingComponent = {
//   name: "GreetingComponent",
//   template: `<h1>Hello World - GreetingComponent</h1>`
// };

// // Global Registration
// Vue.component("greeting", {
//   template: `<h1>Hello from Greetings</h1>`
// })

// // Camel Case
// Vue.component("greetingComponentC", {
//   template: `<h1>Hello from Greeting Component - Camel Cased</h1>`
// })

// // Kebab Case
// Vue.component("greeting-component-check", {
//   template: `<h1>Hello from Greeting Component - Kebab Cased</h1>`
// })

// Vue.component("greeting-data", {
//   template: `<h1>Hello {{name}}</h1>`,
//   data: function(){
//     return {
//       name: "Synechron"
//     };
//   }
// })

// // Root Component
// new Vue({
//   el: '#app',
//   template: `
//     <div>
//       <h1>Hello from Main</h1>
//       <!-- <GreetingComponent />
//       <greetingComponent />
//       <greeting-component /> -->
//       <gc/>
//       <greeting />
//       <greetingComponentC/>
//       <greeting-component-c/>
//       <greeting-component-check />
//       <greeting-data/>
//     </div>
//   `,
//   // components: { GreetingComponent }       // Local Registration
//   components: {
//     'gc': GreetingComponent
//   }       // Local Registration
// });

// ------------------------------------------------------- PreCompiled Templates

// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent';

// Vue.config.productionTip = false

// // var vm = new Vue({
// //   render: function (createElement) {
// //     return createElement(HelloComponent)
// //   }
// // });

// // // console.log(vm);
// // vm.$mount("#app");

// new Vue({
//   render: function (createElement) {
//     return createElement(HelloComponent)
//   }
// }).$mount("#app");

// // ------------------------------------------------------- Using Bootstrap 4
// // npm install bootstrap jquery popper.js
// import 'bootstrap';
// // import 'bootstrap/dist/css/bootstrap.min.css';

// // npm i -D node-sass@4 sass-loader@10
// import 'bootstrap/scss/bootstrap.scss';

// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent';

// Vue.config.productionTip = false

// new Vue({
//   render: function (createElement) {
//     return createElement(HelloComponent)
//   }
// }).$mount("#app");

// ------------------------------------------------------- Multi Components
// import 'bootstrap';
// import 'bootstrap/scss/bootstrap.scss';

// import Vue from 'vue';

// import ComponentOne from './components/2_multi-components/ComponentOne.vue';
// import ComponentTwo from './components/2_multi-components/ComponentTwo.vue';

// Vue.config.productionTip = false

// new Vue({
//   render: function (createElement) {
//     return createElement(ComponentOne)
//   }
// }).$mount("#root1");

// new Vue({
//   render: function (createElement) {
//     return createElement(ComponentTwo)
//   }
// }).$mount("#root2");

// ------------------------------------------------------- Using Single Root
import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';

import Vue from 'vue';

import RootComponent from './components/root/RootComponent.vue';

Vue.config.productionTip = false

new Vue({
  render: function (createElement) {
    return createElement(RootComponent);
  },
  data: {
    id: "root"
  }
}).$mount("#app");