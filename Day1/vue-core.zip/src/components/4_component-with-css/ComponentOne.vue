<template>
  <div>
    <h1 class="text-info">Hello from Component One</h1>
    <h2 class="card">From Component One</h2>
  </div>
</template>

<script>
export default {
  name: "ComponentOne",
};
</script>

<style scoped>
.card {
  margin: 1em;
  padding-left: 0;
  border: 2px solid blue;
}
</style>