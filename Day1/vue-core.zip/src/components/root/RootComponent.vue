<template>
  <div class="container">
    <!-- <component-one />
    <component-two /> -->
    <component-with-data />
  </div>
</template>

<script>
// import ComponentOne from "../2_multi-components/ComponentOne.vue";
// import ComponentTwo from "../2_multi-components/ComponentTwo.vue";

// import ComponentOne from "../3_component-with-inline-style/ComponentOne";
// import ComponentTwo from "../3_component-with-inline-style/ComponentTwo";

// import ComponentOne from "../4_component-with-css/ComponentOne";
// import ComponentTwo from "../4_component-with-css/ComponentTwo";

// import ComponentOne from "../5_css-modules/ComponentOne";
// import ComponentTwo from "../5_css-modules/ComponentTwo";

// import ComponentOne from "../6_external-css/comp-one/ComponentOne";
// import ComponentTwo from "../6_external-css/comp-two/ComponentTwo";

// import ComponentOne from "../7_external-css-css-modules/comp-one/ComponentOne";
// import ComponentTwo from "../7_external-css-css-modules/comp-two/ComponentTwo";

import ComponentWithData from '../8_comp-data/ComponentWithData.vue';

export default {
  name: "RootComponent",
  components: {
    // ComponentOne,
    // ComponentTwo,
    ComponentWithData,
  },
};
</script>