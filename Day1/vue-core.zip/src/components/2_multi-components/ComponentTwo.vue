<template>
  <div class="container">
    <h1 class="text-success">Hello from Component Two</h1>
  </div>
</template>

<script>
export default {
  name: "ComponentTwo",
};
</script>