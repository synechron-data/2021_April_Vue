<template>
  <!-- <div>
    <h1>Hello World</h1>
    <h1>Hello World</h1>
  </div> -->
  <!-- <div class="container">
    <h1 class="text-info">Hello World</h1>
  </div> -->
  <div class="container">
    <h1 class="text-info">Hello World - Enabling Tooltip</h1>
    <button
      type="button"
      class="btn btn-primary"
      data-toggle="tooltip"
      data-placement="top"
      title="Tooltip on top"
    >
      Test Button
    </button>
  </div>
</template>

<script>
import $ from "jquery";

export default {
  name: "HelloComponent",
  mounted: function () {
    $(function () {
      $('[data-toggle="tooltip"]').tooltip();
    });
  },
};
</script>