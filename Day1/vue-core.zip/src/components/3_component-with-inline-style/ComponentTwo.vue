<template>
  <div>
    <h1 class="text-success">Hello from Component Two</h1>
    <h2 style="margin: 1em; padding-left: 0; border: 2px dashed green">
      From Component Two
    </h2>
    <h2 v-bind:style="myStyles">From Component Two</h2>
  </div>
</template>

<script>
export default {
  name: "ComponentTwo",
  data: function () {
    return {
      myStyles: {
        margin: "1em",
        paddingLeft: 0,
        border: "2px dashed green",
      },
    };
  },
};
</script>