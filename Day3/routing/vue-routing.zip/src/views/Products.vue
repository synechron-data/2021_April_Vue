<template>
	<div>
		<h1 class="text-info">Products View</h1>
		<div class="row mt-5">
			<div class="col-4">
				<div class="graybox">
					<ul class="list-group">
						<li
							class="list-group-item"
							v-for="product in productsData"
							:key="product.id"
						>
							<router-link
								:to="{
									name: 'ProductIdLink',
									params: { productId: product.id },
								}"
							>
								{{ product.name }}
							</router-link>
						</li>
					</ul>
				</div>
			</div>
			<div class="col1"></div>
			<div class="col">
				<router-view />
			</div>
		</div>
	</div>
</template>

<script>
	import productsData from "../mixins/product-data.mixin";
	export default {
		name: "ProductsView",
		mixins: [productsData],
	};
</script>

<style>
	.outerdiv {
		display: flex;
	}

	.innerdiv {
		padding: 0 10% 0 10%;
		width: 80%;
		margin: auto;
		background: #ffffff;
	}

	.graybox {
		padding: 10px;
		background: #000000;
		margin-left: auto;
	}
</style>