<template>
	<div class="outerdiv">
		<div class="innerdiv">
			<h2 class="text-warning">Product Details</h2>
			<h3>{{ product.name }}</h3>
			<p>{{ product.description }}</p>
			<hr />
			<h4
				:class="product.status === 'Available' ? 'text-success' : 'text-danger'"
			>
				{{ product.status }}
			</h4>
		</div>
	</div>
</template>

<script>
	import productsInMemoryService from "../../services/product.service";
	export default {
		name: "ProductDetails",
		data() {
			return {
				product: null,
			};
		},
		created() {
			this.loadProduct();
		},
		methods: {
			loadProduct() {
				this.product = productsInMemoryService.getProductById(
					this.$route.params.productId
				);
			},
		},
		watch: {
			"$route.params.productId": function (newValue, oldValue) {
				if (newValue !== oldValue) {
					this.loadProduct();
				}
			},
		},
	};
</script>