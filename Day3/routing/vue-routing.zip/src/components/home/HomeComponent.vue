<template>
	<div>
		<h1 class="text-info">Home Component</h1>
		<h4 class="text-warning">This is a Simple, Vue Routing Application</h4>
	</div>
</template>

<script>
	export default {
		name: "HomeComponent",
	};
</script>