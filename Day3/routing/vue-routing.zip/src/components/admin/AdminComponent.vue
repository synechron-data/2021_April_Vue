<template>
	<div>
		<h1 class="text-info">Admin Component</h1>
		<h4 class="text-success">Welcome, you are an authenticated user.</h4>
		<hr class="mt-5" />
		<h3 class="text-danger">{{ message }}</h3>
		<Table :items="products" />
	</div>
</template>

<script>
	import productsAPIService from "../../services/product-api.service";
	import Table from "../common/datatable/Table";
	export default {
		components: { Table },
		beforeMount() {
			productsAPIService
				.getAllProducts()
				.then((data) => {
					this.products = [...data];
					this.message = "";
				})
				.catch((eMsg) => {
					this.message = eMsg;
				});
		},
		data() {
			return {
				products: [],
				message: "Loading Data, please wait...",
			};
		},
	};
</script>