<template>
	<div class="container">
		<navigation-component />
		<div class="mt-5">
			<router-view />
		</div>
	</div>
</template>

<script>
	import NavigationComponent from "../bs-nav/NavigationComponent.vue";
	export default {
		name: "RootComponent",
		components: {
			NavigationComponent,
		},
	};
</script>

<style>
	nav li a:hover {
		font-weight: bold;
		background-color: indianred;
		cursor: pointer;
	}

	nav li a.router-link-active,
	nav li a.router-link-exact-active {
		border-radius: 15px;
		font-weight: bold;
		text-transform: uppercase;
		background-color: yellowgreen;
		cursor: pointer;
	}
</style>