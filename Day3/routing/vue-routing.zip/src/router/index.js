import Vue from 'vue';
import VueRouter from 'vue-router';

// Eager Loading
import Home from '../views/Home.vue';
// import About from '../views/About.vue';
import Products from '../views/Products.vue';
import ViewNotFound from '../views/ViewNotFound.vue';
// import Admin from '../views/Admin.vue';

import ProductDetails from '../components/products/ProductDetails.vue';
import ProductNotSelected from '../components/products/ProductNotSelected.vue';
// import LoginComponent from '../components/login/LoginComponent.vue';
import authenticator from '../services/authenticator.service';

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    component: Home
  },
  // {
  //   path: '/about',
  //   component: About
  // },
  {
    path: '/about',
    component: () => import(/* webpackChunkName: "bundle-about" */'../views/About.vue')
  },
  {
    path: '/products',
    component: Products,
    children: [
      {
        path: ':productId',
        name: 'ProductIdLink',
        component: ProductDetails
      },
      {
        path: '',
        component: ProductNotSelected
      }
    ]
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import(/* webpackChunkName: "bundle-login" */'../components/login/LoginComponent.vue')
  },
  {
    path: '/admin',
    component: () => import(/* webpackChunkName: "bundle-admin" */'../views/Admin.vue'),
    beforeEnter: (to, from, next) => {

      if (!authenticator.isAuthenticated)
        next({
          name: "Login",
          query: { redirectFrom: to.fullPath }
        });
      else
        next();
    }
  },
  {
    path: '*',
    component: ViewNotFound
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
