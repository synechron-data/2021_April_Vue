import productsInMemoryService from "../services/product.service";

const productsData = {
    data() {
        return {
            productsData: productsInMemoryService.getAllProducts()
        }
    },
};

export default productsData;