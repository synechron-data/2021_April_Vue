
import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { BootstrapVue, BootstrapVueIcons } from 'bootstrap-vue'
import fetchIntercept from 'fetch-intercept';


import Vue from 'vue';

import RootComponent from './components/root/RootComponent.vue';
import router from './router'
import authenticator from './services/authenticator.service';

Vue.config.productionTip = false;
Vue.use(BootstrapVue);
Vue.use(BootstrapVueIcons);

const unregister = fetchIntercept.register({
  request: function (url, config) {
    // Modify the url or config here
    if (new RegExp('api/products').test(url)) {
      config.headers['x-access-token'] = authenticator.getToken();
    }
    return [url, config];
  },

  requestError: function (error) {
    // Called when an error occured during another 'request' interceptor call
    return Promise.reject(error);
  },

  response: function (response) {
    // Modify the reponse object
    return response;
  },

  responseError: function (error) {
    // Handle an fetch error
    return Promise.reject(error);
  }
})

new Vue({
  render: function (createElement) {
    return createElement(RootComponent);
  },

  router,
  name: 'MainComponent',
  destroyed() {
    unregister();
  },
}).$mount("#app");