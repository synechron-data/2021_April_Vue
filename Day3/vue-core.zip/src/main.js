import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';

import Vue from 'vue';

import RootComponent from './components/root/RootComponent.vue';

Vue.config.productionTip = false;

// Vue.config.errorHandler = (err, vm, info) => {
//   // Application Specific Error Handling
// };

new Vue({
  render: function (createElement) {
    return createElement(RootComponent);
  },
  name: 'MainComponent',
}).$mount("#app");