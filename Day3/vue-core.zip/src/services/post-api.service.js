const url = "https://jsonplaceholder.typicode.com/posts";

const postAPIService = {
    getAllPosts: function () {
        // return fetch(url);
        return new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then(data => {
                    setTimeout(() => {
                        resolve(data);
                    }, 5000);
                }).catch((err) => {
                    console.error(err);
                    reject("Parsing Error...");
                })
            }).catch((err) => {
                console.error(err);
                reject("Communication Error...");
            });
        });
    }
};

export default postAPIService;

// Ajax Code
// XMLHttpRequest
// Fetch
// jQuery AJAX
// axios
// vue-resource ($http)