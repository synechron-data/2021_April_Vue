<template>
	<div class="container">
		<ajax-component />
	</div>
</template>

<script>
	import AjaxComponent from "../1_ajax/AjaxComponent.vue";
	export default {
		name: "RootComponent",
		components: {
			AjaxComponent,
		},
	};
</script>