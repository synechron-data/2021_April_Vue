
import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { BootstrapVue, BootstrapVueIcons } from 'bootstrap-vue'

import Vue from 'vue';

import RootComponent from './components/root/RootComponent.vue';
import router from './router'
import store from './store'

Vue.config.productionTip = false;
Vue.use(BootstrapVue);
Vue.use(BootstrapVueIcons);

new Vue({
  render: function (createElement) {
    return createElement(RootComponent);
  },

  router,
  store,
  name: 'MainComponent'
}).$mount("#app");