<template>
	<div class="card">
		<div class="card-body">
			<h1 class="card-title text-center text-primary">{{ total }}</h1>
			<div class="row">
				<div class="col">
					<button
						@click="$emit('increment', target)"
						class="btn btn-success btn-block"
					>
						+
					</button>
				</div>
				<div class="col">
					<button
						@click="$emit('decrement', target)"
						class="btn btn-warning btn-block"
					>
						-
					</button>
				</div>
				<div class="col">
					<button
						@click="$emit('reset', target)"
						class="btn btn-danger btn-block"
					>
						C
					</button>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "CounterComponent",
		props: ["total", "target"],
	};
</script>

<style lang="scss" scoped>
</style>