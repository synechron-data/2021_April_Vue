import Vue from 'vue';
import VueRouter from 'vue-router';

import Home from '../views/Home.vue';
import ViewNotFound from '../views/ViewNotFound.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    component: Home
  },
  {
    path: '/about',
    component: () => import(/* webpackChunkName: "bundle-about" */'../views/About.vue')
  },
  {
    path: '/counter',
    component: () => import(/* webpackChunkName: "bundle-counter" */'../views/Counter.vue')
  },
  {
    path: '/products',
    component: () => import(/* webpackChunkName: "bundle-products" */'../views/Products.vue')
  },
  {
    path: '*',
    component: ViewNotFound
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
