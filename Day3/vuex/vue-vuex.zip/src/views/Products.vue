<template>
	<div>
		<Table :items="products" />
		<hr />
		<Table :items="products" />
	</div>
</template>

<script>
	import { mapState, mapActions } from "vuex";
	import Table from "../components/common/datatable/Table.vue";
	export default {
		components: { Table },
		name: "ProductsView",
		computed: {
			...mapState({ products: (state) => state.productsData.products }),
		},
		async created() {
			await this.getProductsAction();
		},
		methods: {
			...mapActions(["getProductsAction"]),
		},
	};
</script>