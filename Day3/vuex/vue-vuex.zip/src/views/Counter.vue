<template>
	<div>
		<hr />
		<CounterComponent
			:total="total1"
			target="counter1"
			@increment="increment"
			@decrement="decrement"
			@reset="reset"
		/>
		<div class="mt-5 mb-5"></div>
		<CounterComponent
			:total="total2"
			target="counter2"
			@increment="increment"
			@decrement="decrement"
			@reset="reset"
		/>
	</div>
</template>

<script>
	import CounterComponent from "../components/counter/CounterComponent.vue";
	export default {
		components: { CounterComponent },
		name: "CounterView",
		methods: {
			increment(target) {
				this.$store.dispatch(`${target}/increment`);
			},
			decrement(target) {
				this.$store.dispatch(`${target}/decrement`);
			},
			reset(target) {
				this.$store.dispatch(`${target}/reset`, {
					value: 0,
				});
			},
		},
		computed: {
			total1() {
				return this.$store.getters[`counter1/total`];
			},
			total2() {
				return this.$store.getters[`counter2/total`];
			},
		},
	};
</script>