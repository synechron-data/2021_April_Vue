import Vue from 'vue'
import Vuex from 'vuex'

import counter1 from "./modules/counter";
import counter2 from "./modules/counter";
import productsData from './modules/productsData';

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    counter1: counter1,
    counter2: counter2,
    productsData: productsData
  }
})
