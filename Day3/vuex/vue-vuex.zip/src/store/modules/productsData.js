import productsAPI from "../../services/product.service";

export default {
    state: {
        status: "",
        flag: true,
        products: []
    },
    mutations: {
        getProducts(state, data) {
            state.products = data;
        }
    },
    actions: {
        async getProductsAction({ commit }) {
            const data = await productsAPI.getAllProducts();
            commit('getProducts', data);
        }
    }
};